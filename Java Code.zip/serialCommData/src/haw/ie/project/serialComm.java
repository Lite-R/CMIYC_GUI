package haw.ie.project;

/***
 * Authors: Sanchit Bhavsar & Sahitya Mohan Lal
 * Keypad GUI with Serial Communication
 */

import java.io.PrintWriter;
import java.util.Scanner;

import org.eclipse.swt.SWT;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Event;
import org.eclipse.swt.widgets.Group;
import org.eclipse.swt.widgets.Listener;
import org.eclipse.swt.widgets.Shell;

import com.fazecast.jSerialComm.*; // serialcomm library

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;

import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.Text;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.custom.CCombo;
import org.eclipse.wb.swt.SWTResourceManager;

public class serialComm {

	protected Shell shell;
	private Text textBox;
	private CCombo combo;
	private SerialPort port;
	//private OutputStream output;
	static Button sendButton;
	
	/**
	 * Launch the application.
	 * @param args
	 */
	public static void main(String[] args) {
		try {
			serialComm window = new serialComm();
			window.open();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * Open the window.
	 */
	public void open() {
		Display display = Display.getDefault();
		createContents();
		shell.open();
		shell.layout();
		while (!shell.isDisposed()) {
			if (!display.readAndDispatch()) {
				display.sleep();
			}
		}
	}

	/**
	 * Create contents of the window.
	 */
	protected void createContents() {



		shell = new Shell();
		shell.setBackground(SWTResourceManager.getColor(SWT.COLOR_TITLE_INACTIVE_BACKGROUND)); 
		shell.setSize(270, 200);
		shell.setText("Key Application");
		shell.setLayout(new GridLayout(1, false));

		// group composite
		Composite composite = new Group(shell, SWT.NONE);
		composite.setBackground(SWTResourceManager.getColor(SWT.COLOR_TITLE_INACTIVE_BACKGROUND));
		composite.setLayoutData(new GridData(SWT.FILL, SWT.FILL, true, true));
		composite.setLayout(new GridLayout(3, true));

		// Add label to group
		Label label = new Label(composite, SWT.NONE);
		label.setLayoutData(new GridData(SWT.FILL, SWT.FILL, true, true));
		label.setText("Enter Code");

		// Add text box to group
		textBox = new Text(composite, SWT.BORDER);
		textBox.setLayoutData(new GridData(SWT.FILL, SWT.FILL, true, true));
		textBox.setEditable(false);

		// Add combo box to group
		combo = new CCombo(composite, SWT.BORDER);
		combo.setLayoutData(new GridData(SWT.FILL, SWT.FILL, true, true));
		combo.setEditable(false);

		SerialPort[] portNames = SerialPort.getCommPorts(); // Get SerialComm Ports
		for(int i=0; i < portNames.length; i++)
			combo.add(portNames[i].getSystemPortName());   // Add all Comm ports to Combo Box



		// Add buttons to the group
		addButton(composite, "1");
		addButton(composite, "2");
		addButton(composite, "3");
		addButton(composite, "4");
		addButton(composite, "5");
		addButton(composite, "6");
		addButton(composite, "7");
		addButton(composite, "8");
		addButton(composite, "9");
		// Add clear button
		addClearButton(composite, "C");
		addButton(composite, "0");
		// Add send button
		addSendButton(composite, "Send");


	}


	private void addButton(Composite parent, final String label){

		class NumericButtonListner implements Listener {

			@Override
			public void handleEvent(Event event) {
				// TODO Auto-generated method stub

				// Append label text to button 
				textBox.setText(textBox.getText() + label);
			}

		}

		Button button = new Button(parent, SWT.PUSH);
		button.setLayoutData(new GridData(SWT.FILL, SWT.FILL, true, true));
		button.setText(label);
		Listener buttonlistner = new NumericButtonListner();
		button.addListener(SWT.Selection, buttonlistner);


	}

	private void addClearButton(Composite parent, final String clearString)
	{
		class ClearButtonListener implements Listener {

			@Override
			public void handleEvent(Event event) {
				// TODO Auto-generated method stub
				textBox.setText("");

			}

		}

		Button clearButton = new Button(parent, SWT.PUSH);
		clearButton.setLayoutData(new GridData(SWT.FILL, SWT.FILL, true, true));
		clearButton.setText(clearString);
		Listener listener = new ClearButtonListener();
		clearButton.addListener(SWT.Selection, listener);


	}

	private void addSendButton(Composite parent, final String string)
	{
		class SendButtonListener implements Listener {

			@Override
			public void handleEvent(Event event) {
				// TODO Auto-generated method stub

				SerialPort port = SerialPort.getCommPort("COM4");
				port.setBaudRate(9600);
				port.setComPortParameters(9600, 8, SerialPort.TWO_STOP_BITS, SerialPort.NO_PARITY);
				//port.setComPortTimeouts(SerialPort.TIMEOUT_READ_SEMI_BLOCKING | SerialPort.TIMEOUT_WRITE_SEMI_BLOCKING, 0, 0);
				port.setComPortTimeouts(SerialPort.TIMEOUT_SCANNER, 0, 0);
				//TIMEOUT_SCANNER 
				port.setFlowControl(SerialPort.FLOW_CONTROL_DISABLED);
				if(port.openPort() == false) {
					System.err.println("Unable to open the port.");
					return;
				}
				PrintWriter output = new PrintWriter(port.getOutputStream());
				Scanner s = new Scanner(port.getInputStream());
				//while(true){
					//char writtenOut = textBox.getTextChars()[0];
					String writtenOut = textBox.getText();
					output.write(writtenOut);
					output.flush();
					System.out.println("You Output: "+ writtenOut);
					try {Thread.sleep(100); } catch(Exception e) {}
					String characterReceived = "";
					try {
						while(port.getInputStream().available()>0)
							characterReceived += (char)(port.getInputStream().read());
					} catch (IOException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
					System.out.println("Line of text from serial port: " + characterReceived);
				//}
			}
		}

		sendButton = new Button(parent, SWT.PUSH);
		sendButton.setLayoutData(new GridData(SWT.FILL, SWT.FILL, true, true));
		sendButton.setText(string);
		Listener listener = new SendButtonListener();
		sendButton.addListener(SWT.Selection, listener);

	}


}
