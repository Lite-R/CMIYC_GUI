/*
 * Serial Communication via UART 1
 * The program receive letter from keyboard and display it on terminal.
 * Stop bit     : 1
 * Data bit     : 8
 * Parity bit   : None
 * Stop bit     : 2
 *
 * HalCoGen steps:
 * 1. From TMS570Lxx /RMx -> Enable Drivers unmark all drivers except SCI1
 * 2. From SCI
 *      2.1 activate receive interrupt
 *      2.2 Set the stop bit, start bit ...
 * 3. From VIM 0 - 31 channel activate channel 13
 * 4. Generate the code
 * 5. Jump to CCS
 */
/* USER CODE BEGIN (0) */
#include "HL_sci.h"
/* USER CODE END */

/* Include Files */

#include "HL_sys_common.h"
#include "HL_system.h"

/* USER CODE BEGIN (1) */
static unsigned char ReceivedData;
#define UART sciREG1
/* USER CODE END */


/* USER CODE BEGIN (2) */
/* USER CODE END */

int main(void)
{
/* USER CODE BEGIN (3) */
    //enable IRQ interrupt
    _enable_IRQ();
    //Initialize the sci
    sciInit();

    unsigned char charArray[4];
    int counter = 0;
    int i = 0;

    //sending text DONE BY GUI
    //sciSend(UART, 10, (unsigned char *)"Enter PIN \r \n");


    //Store the received data in ReceivedData
    sciReceive(UART, 1, (unsigned char *)&ReceivedData);

    //run forever
    while(1) {
        if (sciIsRxReady(UART)) {
            sciReceive(UART, 1, (unsigned char *)&ReceivedData);
            charArray[counter] = ReceivedData;
            counter++;
            if (counter == 4) {
                while (i!=4)
                {
                    sciSend(UART, 1, (unsigned char *)&charArray[i]);
                    i++;
                }
                counter = 0;
                i=0;
            }
        }
    }
/* USER CODE END */

    //return 0;
}


/* USER CODE BEGIN (4) */
void sciNotification(sciBASE_t *sci, uint32 flags)
{
/*  enter user code between the USER CODE BEGIN and USER CODE END. */
/* USER CODE BEGIN (32)
    if (ReceivedData =='1') {
    //sciSend(sci, 1, (unsigned char *) &ReceivedData);
        sciSend(UART, 10, (unsigned char *)"Enter SUK \r \n");
    }

    else {

        sciSend(UART, 10, (unsigned char *)"Enter FIL \r \n");
    }*/
    //sciReceive(sci, 1, (unsigned char *) &ReceivedData);
/* USER CODE END */
}

void esmGroup1Notification(int bit)
{
/*  enter user code between the USER CODE BEGIN and USER CODE END. */
/* USER CODE BEGIN (1) */
    return;
/* USER CODE END */
}

void esmGroup2Notification(int bit)
{
/*  enter user code between the USER CODE BEGIN and USER CODE END. */
/* USER CODE BEGIN (3) */
    return;
/* USER CODE END */
}
/* USER CODE END */
